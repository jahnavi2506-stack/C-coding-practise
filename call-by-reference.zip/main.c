#include<stdio.h>
void swap(int a,int b);
int main()
{
    int x,y;
    x=5;
    y=6;
    printf("before swapping the values in main=%d %d",x,y);
    swap(x,y);
    printf("\nafter swapping the values in main=%d %d",x,y);
    return 0;
}
void swap(int a,int b)
{
    int temp;
    temp=a;
    a=b;
    b=temp;
printf("\nAfter swapping values in function=%d %d",a,b);
}

