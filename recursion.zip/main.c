#include <stdio.h>
int main()
{
    int a=1;
    int main()
    {
        display();
        printf("helo");
        int display();
        {
            if(a<=2)
            {
                printf("hello");
                a++;
                display();
            }
        }
    }
    printf("hey");
}
