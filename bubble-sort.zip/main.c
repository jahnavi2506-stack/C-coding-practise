#include <stdio.h>
int main()
{
 int arr[50],num,x,y,temp;
 printf("please enter the no.of elements you want in the array:");
 scanf("%d",&num);
 printf("please enter the values of elements:");
 for(x=0;x<num;x++)
{
 scanf("%d",&arr[x]);
}
for(x=0;x<num-1;x++)
{
for(y=0;y<num-x-1;y++)
{
 if(arr[y]>arr[y+1])
 {
     temp=arr[y];
     arr[y]=arr[y+1];
     arr[y+1]=temp;
 }
 }
}
printf("Array after implementing bubble sort:");
for(x=0;x<num;x++)
{
    scanf("%d",&arr[x]);
}
return 0;
}
