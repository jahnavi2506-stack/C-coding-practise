#include<stdio.h>
int main()
{
    int N,sum=0,count=1;
    printf("Enter N value:");
    scanf("%d",&N);
    while(count<=N)
    {
        sum=sum+count;
        count++;
    }
    printf("sum=%d\n",sum);
    return 0;
}