#include<stdio.h>
int main()
{
 float amt,gst,total;
 int a,product,cost;
  a=5231110;
 printf("Bill No:%d\n",a);
 printf("\n super mart name:AVENUE SUPER MART LTD");
 printf("\n enter the amount:");
 scanf("%f",&amt);
if(amt<=1000)
{
    cost=750;
    gst=amt*12/100;
    total=gst+amt;
    printf("gst=%f\n",gst);
    printf("total=%f",total);
}
  else if(amt>=1001 && amt<=3000)
  {
      cost=1500;
      gst=amt*20/100;
      total=gst+amt;
      printf("gst=%f\n",gst);
      printf("total=%f",total);
  }
  else if(amt>=3001 && amt<=6000)
    {
        cost=3550;
        gst=amt*28/100;
        total=gst+amt;
        printf("gst=%f\n",gst);
        printf("total=%f",total);
    }
 else if(amt>=6001 && amt<=9000)
    {
        cost=6500;
        gst=amt*36/100;
        total=gst+amt;
        printf("gst=%f\n",gst);
        printf("total=%f",total);
    }
    else
    {
        cost=10054;
        gst=amt*50/100;
        total=gst+amt;
        printf("gst=%f\n",gst);
        printf("total=%f",total);
    }
 return 0;
}
